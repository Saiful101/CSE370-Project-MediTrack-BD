<?php
$base = "http://localhost/MediTrackBD";
$is_admin = isset($_SESSION['admin_id']);
$is_doctor = ($_SESSION['user_type'] ?? '') == 'Doctor';
$person_id = $_SESSION['person_id'] ?? 0;
$name = $_SESSION['name'] ?? 'User';

// Get current page for active state
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
?>

<nav class="navbar navbar-expand-lg" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
    <div class="container-fluid">
        <a class="navbar-brand text-white fw-bold" href="<?php echo $base; ?>/patient/dashboard.php">MediTrack<span>BD</span></a>
        <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <?php if($is_admin): ?>
                <!-- Admin Navigation -->
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'admin' && $current_page == 'dashboard.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'analytics') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/analytics/index.php"><i class="bi bi-graph-up"></i> Analytics</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'emergency') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/emergency/index.php"><i class="bi bi-exclamation-triangle"></i> Emergency</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'history.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/patient/history.php"><i class="bi bi-people"></i> Patients</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'appointments') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/appointments/list.php"><i class="bi bi-calendar-check"></i> Appointments</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'create.php' && $current_dir == 'prescription') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/prescription/create.php"><i class="bi bi-file-medical"></i> Prescriptions</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'pharmacy') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/pharmacy/index.php"><i class="bi bi-capsule"></i> Pharmacy</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'bloodbank') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/bloodbank/index.php"><i class="bi bi-droplet"></i> Blood Bank</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'hospitals.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/admin/hospitals.php"><i class="bi bi-hospital"></i> Hospitals</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'ambulances.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/admin/ambulances.php"><i class="bi bi-ambulance"></i> Ambulances</a></li>
                <?php elseif($is_doctor): ?>
                <!-- Doctor Navigation -->
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'patient' && $current_page == 'dashboard.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/patient/dashboard.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'create.php' && $current_dir == 'prescription') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/prescription/create.php"><i class="bi bi-file-medical"></i> Prescriptions</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'appointments') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/appointments/list.php"><i class="bi bi-calendar-check"></i> Appointments</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'emergency') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/emergency/index.php"><i class="bi bi-exclamation-triangle"></i> Emergency</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'history.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/patient/history.php"><i class="bi bi-people"></i> Patients</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'pharmacy') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/pharmacy/index.php"><i class="bi bi-capsule"></i> Pharmacy</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'bloodbank') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/bloodbank/index.php"><i class="bi bi-droplet"></i> Blood Bank</a></li>
                <?php else: ?>
                <!-- Patient Navigation -->
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'patient' && $current_page == 'dashboard.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/patient/dashboard.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'appointments' && $current_page == 'book.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/appointments/book.php"><i class="bi bi-calendar-plus"></i> Book Appointment</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'emergency') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/emergency/index.php"><i class="bi bi-exclamation-triangle"></i> Emergency</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'appointments' && $current_page == 'list.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/appointments/list.php"><i class="bi bi-list-check"></i> My Appointments</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_page == 'history.php') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/patient/history.php"><i class="bi bi-file-medical"></i> Prescriptions</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'bloodbank') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/bloodbank/index.php"><i class="bi bi-droplet"></i> Blood Bank</a></li>
                <li class="nav-item"><a class="nav-link text-white <?php echo ($current_dir == 'pharmacy') ? 'active fw-bold' : ''; ?>" href="<?php echo $base; ?>/pharmacy/index.php"><i class="bi bi-capsule"></i> Pharmacy</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link text-white dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> <?php echo $name; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?php echo $base; ?>/index.php?logout=1"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
